Create table #CostRep (DishName NVarchar(255), ProductionCost Float)
Insert into #CostRep 
select ��������, ���� from VPrice

Select top 3 * from #CostRep order by ProductionCost
Select top 3 * from #CostRep order by ProductionCost desc