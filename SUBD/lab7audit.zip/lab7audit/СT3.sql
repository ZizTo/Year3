use lab1SUBD
go
disable trigger trig2 on Student
go
Delete from Student where fio='� � �'
Select * from StudArch