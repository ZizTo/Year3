import React from 'react';
import ReactDOM from 'react-dom/client';
import AppNew from './components/AppNew';

const container = document.getElementById('reactapp');
const root = ReactDOM.createRoot(container);
root.render(<AppNew />);