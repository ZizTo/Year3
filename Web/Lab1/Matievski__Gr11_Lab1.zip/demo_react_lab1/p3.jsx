import React from "react"; 
import ReactDOM from "react-dom/client";

import FuncAvto from "./components/Avto";

const container = document.getElementById('reactapp');
const root = ReactDOM.createRoot(container);
root.render(<FuncAvto />);
